package es.uam.eps.bmi.search.index.structure;

/**
 *
 * @author pablo
 */
public interface PostingsList extends Iterable<Posting> {
    public int size();
}
