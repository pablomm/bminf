package es.uam.eps.bmi.search.ranking;

import java.util.Iterator;

/**
 *
 * @author pablo
 */
public interface SearchRankingIterator extends Iterator<SearchRankingDoc> {
}
