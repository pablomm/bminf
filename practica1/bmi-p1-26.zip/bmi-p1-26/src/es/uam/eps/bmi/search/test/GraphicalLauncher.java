/**
 * 
 */
package es.uam.eps.bmi.search.test;

import es.uam.eps.bmi.search.ui.view.BuilderWindow;


/**
 * Lanza la interfaz grafica
 *
 */
public class GraphicalLauncher {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Simplemente lanza la ventana del builder que desencadena toda la interfaz
		new BuilderWindow();

	}

}
